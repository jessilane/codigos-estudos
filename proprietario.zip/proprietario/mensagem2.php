<?php
 include "banco_restaurante.php";
 


 $codigo= $_GET['id'];

 
 //echo "dados deletados com sucesso!";
echo "<script> confirm('Você Nao pode excluir esse resistro DEIXE SUA MENSAGEM!')</script>";
 echo "alert";
 echo "<script>window.location=\"i_mensagem2.php\"</script>";
 ?>  