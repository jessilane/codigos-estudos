
<html>
	<head>
		<title>J.T restaurant</title>
				<link rel="shortcut icon" href="imagem/.jpg" type="imagem/x=jpg"/>

	    <link rel="stylesheet" type="text/css"  href="css/css.css" />

		<meta charset="UTF-8" />
      
	</head>
   <body background="imagem/.jpg">
	
	
            
            <img src="imagem/cam1.jpg" width="2px" height="2px"/>
			<br>
			<br>
            <a class="bute" href="">J.T restaurant</a><br>           
			<br>
			
			<div class="menuu" >
			<nav class="menu">
  <ul>
		<li><a href="index.php">Home</a></li>
	  		<li><a href="cardapio.php">Cardápio</a>	</li>
	  		<li><a href="reserva_mesas.php">Resevar Mesa</a>	</li>		
			<li><a href="i_pedido.php"> Fazer um Pedido!</a>	</li>

	  		<li><a href="i_cliente.php"> Faça seu Cadastro!</a>	</li>
		
</ul>
</nav>

	<br>
<br>
<br>
<br>
<br>
<br>
<br>


<br>
<center>

	<nav class="subemenu">
  <ul>
		<li><img src="imagem/ftgarcom.png"  width="70px" height="75px"/>
<a  href="loginGa.php">Entrar como Garçom?</a>
</li>
		<br>
		<br>
	
		
	  		<li> <img src="imagem/ftgerente.png"  width="70px" height="75px"/>
			<a href="loginGe.php">Entrar como Gerente?</a>
			</li>
			<br>
			<br>
	  		<li><img src="imagem/ftpro.png"  width="70px" height="75px"/><a href="loginPro.php">Entrar como Proprietario?</a>
				</li>
		
</ul>
</nav>




</body>
</center>
</html>