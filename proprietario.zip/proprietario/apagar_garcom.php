<?php
 include "banco_restaurante.php";
  require"veriLogPro.php";


 $codigo= $_GET['id'];
  
 mysql_query("DELETE FROM garcom where id_funci = $codigo");
 mysql_close($conexao);
 
 //echo "dados deletados com sucesso!";
 echo "<meta charset=UTF-8> <script> alert('Registro excluido') </script>";
 echo "<script>window.location=\"list.php\"</script>";
 ?>  