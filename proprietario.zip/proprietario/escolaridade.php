
<html>
<head>
<html>
	<head>
		<title> J.T restaurant</title>
				<link rel="shortcut icon" href="imagem/.jpg" type="imagem/x=jpg"/>

	    <link rel="stylesheet" type="text/css"  href="css/css.css" />

		<meta charset="UTF-8" />
      
	</head>
	

	 <body background="imagem/.jpg">
<font face="verdana" color=""/>

            
            <a class="bute" href=""> J.T restaurant</a>
						<nav class="menu">
  <ul>
		<li><a href="index.php">HOME</a></li>
	  		<li><a href="">CARDÁPIO</a>	</li>
		<li><a href=".html">CONTATO</a></li>
		<li><a href=".html"> MESA</a></li>
		
		<li><a href="area_restrita.php">USUARIOS</a></li>
  <img src="imagem/.jpg" width="50px" height="50px"/>
		
</ul>
</nav>


<br>
<br>
<br>
<br>
<br>
<br>
<br>


<br>
<center>
<h2> Inserir uma nova escolaridade </h2>
<br>
<br>

<form id="" name="" enctype="multipart/form-data" action="inserir.php" method="post">

escolaridade :<input id="escolaridade" type="text" name="escolaridade" size="40" />
<p></p>
<br>


<input type="submit" name="Inserir" id="Inserir" value="Inserir"> </button>
<input type="reset" value="Limpar"> </button>
 
   
</form>
</center>






</body>
</html>